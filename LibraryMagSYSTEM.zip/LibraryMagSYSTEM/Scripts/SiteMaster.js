﻿$(document).ready(function() {
    $('.frmDate').keypress(function (e) { e.preventDefault(); });
    $('.toDate').keypress(function (e) { e.preventDefault(); });
    $('.frmDate1').keypress(function (e) { e.preventDefault(); });
    $('.toDate1').keypress(function (e) { e.preventDefault(); });
    $('.datepicker').keypress(function (e) { e.preventDefault(); });
    $('.empdatepicker').keypress(function (e) { e.preventDefault(); });
    $('.dtpicker').keypress(function (e) { e.preventDefault(); });
    $('.clkpicker').keypress(function (e) { e.preventDefault(); });
    $('.txtPrevent').keypress(function (e) { e.preventDefault(); });

    $(".datepicker").datepicker(
       {
           dateFormat: 'dd/mm/yy',
           changeMonth: false,
           changeYear: false,
           maxDate:0
       });

    $('.txtdec').keyup(function () {
        var val = $(this).val();
        if (isNaN(val)) {
            val = val.replace(/[^0-9\.]/g, '');
            if (val.split('.').length > 2)
                val = val.replace(/\.+$/, "");
        }
        $(this).val(val);
    });

    $(".empdatepicker").datepicker(
{
    dateFormat: 'dd/mm/yy',
    yearRange: "-50:+0", 
    changeMonth: true,
    changeYear: true,
    maxDate:0
});
    $(".frmDate").datepicker({
        dateFormat: 'dd/mm/yy',
        maxDate:0,
        numberOfMonths: 1,
        onSelect: function(selected) {
            $(".toDate").datepicker("option","minDate", selected)
        }
    });
    $(".toDate").datepicker({ 
        dateFormat: 'dd/mm/yy',
        minDate: 0,
        maxDate: 365,
        onSelect: function(selected) {
            $(".frmDate").datepicker("option","maxDate", selected)
        }
    });  
    $(".frmDate1").datepicker({
        dateFormat: 'dd/mm/yy',
        maxDate:0,
        numberOfMonths: 1,
        onSelect: function(selected) {
            $(".toDate1").datepicker("option","minDate", selected)
        }
    });
    $(".toDate1").datepicker({ 
        dateFormat: 'dd/mm/yy',
        minDate: 0,
        maxDate: 0,
        onSelect: function(selected) {
            $(".frmDate1").datepicker("option","maxDate", selected)
        }
    }); 

    $('.clkpicker').clockpicker({
        placement: 'bottom',
        align: 'left',
        donetext: 'Done'
    });

    $('.clkpicker1').clockpicker({
        placement: 'bottom',
        align: 'left',
        donetext: 'Done'
    });




    $(".dtpicker").datepicker(
       {
           dateFormat: 'dd/mm/yy',
           changeMonth: false,
           changeYear: false,
           maxDate: 365
       });
    $(".sidebar-dropdown > a").click(function() {
        $(".sidebar-submenu").slideUp(200);
        if ($(this).parent().hasClass("active")) {
            $(".sidebar-dropdown").removeClass("active");
            $(this).parent().removeClass("active");
        } else {
            $(".sidebar-dropdown").removeClass("active");
            $(this).next(".sidebar-submenu").slideDown(200);
            $(this).parent().addClass("active");
        }
    });

    $("#close-sidebar").click(function() {
        $(".page-wrapper").removeClass("toggled");
    });
    $("#show-sidebar").click(function() {
        $(".page-wrapper").addClass("toggled");
    });

    $('#table').dataTable({
        aoColumnDefs: [{
            bSortable: false,
            aTargets: [0, -1, -2, 2]
        }]
    });
    //$('.customSelect').fSelect();
});


function sidebar_toggle() {
    $(".page-wrapper").toggleClass("toggled");
}

function prle_d_tgle() {
    $(".profile_card_design").slideToggle("slow");
    $('.profilelogostyle').toggleClass('toglebdecls');
}

//let ddlCity = $('#ddlCity');
//const getCity = async (EmpId) => {
//    alert("CityOk")
//    await axios.get('http://prematix.net/VCMCAPI/VCMCService.svc/GetCityData?EmpId=17')
//      .then(async (res) => {
//          const {data} = res;
//          const response = data[0]["Response"];
//          await _.map(response,v=>{
//              let temp = `<option value="${v.CityId}"> ${v.CityName}</option>`;
//              console.log(temp)
//              ddlCity.append(temp)
//          })
//          $(select).selectpicker('refresh');
//      })
//            .catch(function(error) {
//                console.log(error);
//            });
//}



//let $ddlZone = $('#ddlZone');

//const ZonyByCity = async (City) => {    

//    alert(City)

//    $ddlZone.empty()
//    console.log($ddlZone);
//    await axios.get('http://prematix.net/VCMCAPI/VCMCService.svc/ZoneByCity?EmpId=17&City='+City+'')
//      .then(async (res) => {
     
//          console.log(res);
//          const {data} = res;
//          const response = data[0]["Response"];
//          await _.map(response,v=>{
//              let temp = `<option value="${v.ZoneId}"> ${v.ZoneName}</option>`;
//              console.log(temp)
//              $ddlZone.append(temp)
//          })
//          $ddlZone.fSelect('destroy').fSelect('create');

//    })
//            .catch(function(error) {

//                console.log(error);
//                console.log($ddlZone);
//    });
//}

//let $ddlMMC = $('#ddlMMC');
//const MCCByZone = async (City, Zone) => {
//    $ddlMMC.empty()
//    console.log(Zone)
//    await axios.get('http://prematix.net/VCMCAPI/VCMCService.svc/MCCByZone?EmpId=17&City=1&Zone='+Zone+'')
//      .then(async (res) => {
//          console.log(res);
         
//          const {data} = res;
//          const response = data[0]["Response"];
//          await _.map(response,v=>{
//              let temp = `<option value="${v.MCCId}"> ${v.MCCName}</option>`;
//              console.log(temp)
//              $ddlMMC.append(temp)
//          })
//          $ddlMMC.fSelect('destroy').fSelect('create');

         

//      })
//            .catch(function(error) {
//                console.log(error);
//            });
//}

//let $ddlWard = $('#ddlMMC');
//const WardByMCC = async (City, Zone, MCC) => {
//    $ddlWard.empty();
//    console.log(Zone,MCC)
//    await axios.get('http://prematix.net/VCMCAPI/VCMCService.svc/WardByMCC?EmpId=17&City=1&Zone='+Zone+'&MCC='+MCC+'')
//      .then(async (res) => {
//          console.log(res);
        
//          const {data} = res;
//          const response = data[0]["Response"];
//          await _.map(response,v=>{
//              let temp = `<option value="${v.WardId}"> ${v.WardName}</option>`;
//              console.log(temp)
//              $ddlWard.append(temp)
//          })
//          $ddlWard.fSelect('destroy').fSelect('create');

//      })
//            .catch(function(error) {
//                console.log(error);
//            });
//}

const chartDataGet = async (Year, City, Zone, MCC, Ward) => {
 
    console.log(Year, City, Zone, MCC,Ward)
    //await axios.get('http://192.168.1.220:8081/VCMCService.svc/GetDashboardMonthWise?Year='+Year+'&City='+City+'&Zone='+Zone+'&MCC='+MCC+'&Ward='+Ward+'')
    await axios.get('http://prematix.net/VCMCAPI/VCMCService.svc/GetDashboardMonthWise?Year='+Year+'&City='+City+'&Zone='+Zone+'&MCC='+MCC+'&Ward='+Ward+'')
       .then(async (res) => {
           console.log(res);
           const {
               data
           } = res;

           let obj={};
           if (data[0]["Status"] == "Ok")
           {
               const response = data[0]["Response"][0];
               const {
                   DisposalCount,
                   DryWeight,
                   TotalWeight,
                   WetWeight
               } = response
               let tmpDisposalCount = DisposalCount.split(',');
               let tmpDryWeight = DryWeight.split(',');
               let tmpTotalWeight = TotalWeight.split(',');
               let tmpWetWeight = WetWeight.split(',');
               obj = {
                   disposalCount: await _.map(tmpDisposalCount, v => parseInt(v)),
               dryWeight: await _.map(tmpDryWeight, v => parseInt(v)),
               totalWeight: await _.map(tmpTotalWeight, v => parseInt(v)),
               wetWeight: await _.map(tmpWetWeight, v => parseInt(v)),

               }
            
       }else{
          obj = {
    disposalCount:0,
    dryWeight:0,
    totalWeight:0,
    wetWeight: 0,

    }
            
}
lineChartDrow(obj)
})
        .catch(function(error) {
            console.log(error);
        });

//await axios.get('http://192.168.1.220:8081/VCMCService.svc/GetDashboardCurrentMonth?Year='+Year+'&City='+City+'&Zone='+Zone+'&MCC='+MCC+'&Ward='+Ward+'')
await axios.get('http://prematix.net/VCMCAPI/VCMCService.svc/GetDashboardCurrentMonth?Year='+Year+'&City='+City+'&Zone='+Zone+'&MCC='+MCC+'&Ward='+Ward+'')
.then(async (res) => {
    console.log(res);

    const {
        data
    } = res;

    let obj =[];
    if (data[0]["Status"] == "Ok") 
    {
        const response = data[0]["Response"][0];
        const {
            DisposalPercent,
            DryPercent,
            TotalPercent,
            WetPercent,
            WetWeight,
            DryWeight,
            DisposalCount,
            TotalWeight
        } = response
        //
        console.log(response)


        obj = [{
            name: 'Wet Wastage',
            y: parseFloat(WetPercent),
            text: WetWeight
        },
            {
                name: 'Dry Wastage',
                y: parseFloat(DryPercent),
                text: DryWeight
            },
            {
                name: 'Disposed Wastage',
                y: parseFloat(DisposalPercent),
                text: DisposalCount
            },
            {
                name: 'Total Wastage ',
                y: parseFloat(TotalPercent),
                text: TotalWeight
            },

        ]
    }else{
        obj = [{
            name: 'Wet Wastage',
            y: 0,
            text: '0'
        },
           {
               name: 'Dry Wastage',
               y: 0,
               text: '0'
           },
           {
               name: 'Disposed Wastage',
               y: 0,
               text: '0'
           },
           {
               name: 'Total Wastage ',
               y: 0,
               text: '0'
           },

        ]
            
    }
    pieChartDrow(obj)

})
.catch(function(error) {
    console.log(error);
});

//await axios.get('http://192.168.1.220:8081/VCMCService.svc/GetDashboardLast4Month?City='+City+'&Zone='+Zone+'&MCC='+MCC+'&Ward='+Ward+'')
await axios.get('http://prematix.net/VCMCAPI/VCMCService.svc/GetDashboardLast4Month?City='+City+'&Zone='+Zone+'&MCC='+MCC+'&Ward='+Ward+'')
.then(async (res) => {
    console.log(res);

    const {
        data
    } = res;
    if (data[0]["Status"] !== "Ok") return alert('No data found')
    const response = data[0]["Response"][0];
    const {
        DisposalCount,
        DryWeight,
        TotalWeight,
        WetWeight
    } = response
    let tmpDisposalCount = DisposalCount.split(',');
    let tmpDryWeight = DryWeight.split(',');
    let tmpTotalWeight = TotalWeight.split(',');
    let tmpWetWeight = WetWeight.split(',');
    const obj = {
        disposalCount: await _.map(tmpDisposalCount, v => parseInt(v)),
    dryWeight: await _.map(tmpDryWeight, v => parseInt(v)),
    totalWeight: await _.map(tmpTotalWeight, v => parseInt(v)),
    wetWeight: await _.map(tmpWetWeight, v => parseInt(v)),
    }
BarChartDrow(obj)
})
        .catch(function(error) {
            console.log(error);
        });
}

/****************  Train Employee Image*****************/
const TrainEmpImage = async () => {
    await axios.get('http://192.168.1.220/FaceRecognitionApi/datatrain')
      .then(async (res) => {
          console.log(res);

          const {
              data
          } = res;
          if (data[0]["Status"] !== "Ok") return alert('No data found')
          const response = data[0]["Response"][0];
          Console.log(response)

      })
    .catch(function(error) {
        console.log(error);
    });

}
   

/************* End ********************/

const lineChartDrow = data => {
    const {
        disposalCount,
        dryWeight,
        totalWeight,
        wetWeight
    } = data;
    $(document).ready(function() {
        // line Chart
        Highcharts.chart('lineChart', {
            chart: {
                type: 'areaspline'
            },
            title: {
                text: 'Wastage collected graph '
            },
            xAxis: {
                allowDecimals: false,
                categories: ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'],
                labels: {
                    formatter: function(e) {
                        return this.value;
                    }
                }
            },
            yAxis: {
                title: {
                    text: 'Wastage'
                },
                labels: {
                    formatter: function() {
                        return this.value + 'kg';
                    }
                }
            },
            tooltip: {
                pointFormat: '{series.name} had stockpiled <b>{point.y:,.0f}</b><br/>Kg'
            },
            series: [{
                name: 'Dry Wastage',
                data: dryWeight
            }, {
                name: 'Wet Wastage',
                data: wetWeight
            },
                {
                    name: 'Disposed Wastage',
                    data: disposalCount
                },
                {
                    name: 'Total Wastage',
                    data: totalWeight
                }

            ]
        });
        //piChart

    });

}


const pieChartDrow = data => {
    console.log(data)
    Highcharts.chart('piChart', {
        chart: {
            plotBackgroundColor: null,
            plotBorderWidth: null,
            plotShadow: false,
            type: 'pie'
        },
        title: {
            text: 'Month to Date – Wastage collected graph '
        },
        tooltip: {
            pointFormat: '{series.name}: <b>{point.percentage:.1f}%</b>'
        },
        plotOptions: {
            pie: {
                allowPointSelect: true,
                cursor: 'pointer',
                dataLabels: {
                    enabled: true,
                    format: '<b>{point.name}</b>: {point.text} Kg',
                    style: {
                        color: (Highcharts.theme && Highcharts.theme.contrastTextColor) || 'black'
                    },
                    connectorColor: 'silver'
                }
            }
        },
        series: [{
            data,
            name: 'Share',

        }]
    });

}



const BarChartDrow = data => {
    const {
        disposalCount,
        dryWeight,
        totalWeight,
        wetWeight
    } = data;
    Highcharts.chart('barChart', {
        chart: {
            type: 'column'
        },
        title: {
            text: 'Last 4 Monthly wastage collected graph '
        },

        xAxis: {
            categories: [
                'Jan',
                'Feb',
                'Mar',
                'Apr',

            ],
            crosshair: true
        },
        yAxis: {
            title: {
                text: 'Wastage'
            },
            labels: {
                formatter: function() {
                    return this.value + 'kg';
                }
            }
        },
        tooltip: {
            headerFormat: '<span style="font-size:10px">{point.key}</span><table>',
            pointFormat: '<tr><td style="color:{series.color};padding:0">{series.name}: </td>' +
                '<td style="padding:0"><b>{point.y:.1f} Kg</b></td></tr>',
            footerFormat: '</table>',
            shared: true,
            useHTML: true
        },
        plotOptions: {
            column: {
                pointPadding: 0.2,
                borderWidth: 0
            }
        },
        series: [{
            name: 'Wet Wastage',
            data: wetWeight

        }, {
            name: 'Dry Wastage',
            data: dryWeight

        }, {
            name: 'Disposed Wastage',
            data: disposalCount

        }, {
            name: 'Total Wastage',
            data: totalWeight

        }]
    });

}