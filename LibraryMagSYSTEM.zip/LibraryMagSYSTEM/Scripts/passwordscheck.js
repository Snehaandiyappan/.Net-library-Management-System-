﻿$(document).ready(function () {
  
    $('.txtUserPassword').keyup(function () {
        console.log('hi')
        $('.result').html(checkStrength($('.txtUserPassword').val()))
    })
    
});


function checkStrength(txtUserPassword) {
    var strength = 0
    if (txtUserPassword.length < 6) {
        $('.result').removeClass('weak good strong')
        $('.result').addClass('short')
        return 'Too short'
    }
    if (txtUserPassword.length > 7) strength += 1
    // If password contains both lower and uppercase characters, increase strength value.
    if (txtUserPassword.match(/([a-z].*[A-Z])|([A-Z].*[a-z])/)) strength += 1
    // If it has numbers and characters, increase strength value.
    if (txtUserPassword.match(/([a-zA-Z])/) && txtUserPassword.match(/([0-9])/)) strength += 1
    // If it has one special character, increase strength value.
    if (txtUserPassword.match(/([!,%,&,@,#,$,^,*,?,_,~])/)) strength += 1
    // If it has two special characters, increase strength value.
    if (txtUserPassword.match(/(.*[!,%,&,@,#,$,^,*,?,_,~].*[!,%,&,@,#,$,^,*,?,_,~])/)) strength += 1
    // Calculated strength value, we can return messages
    // If value is less than 2
    if (strength < 2) {
        $('.result').removeClass('weak good strong')
        $('.result').addClass('weak')
        return 'Weak'
    } else if (strength == 2) {
        $('.result').removeClass('weak good strong')
        $('.result').addClass('good')
        return 'Good'
    } else {
        $('.result').removeClass('weak good strong')
        $('.result').addClass('strong')
        return 'Strong'
    }
}