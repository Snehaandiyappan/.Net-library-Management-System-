﻿using Microsoft.Owin;
using Owin;

[assembly: OwinStartupAttribute(typeof(LibraryMagSYSTEM.Startup))]
namespace LibraryMagSYSTEM
{
    public partial class Startup {
        public void Configuration(IAppBuilder app) {
            ConfigureAuth(app);
        }
    }
}
